</div>
</div>
<div class="content-overlay"></div>
</div>
</div>
</div>
<!-- END: Page Main-->
<!-- Theme Customizer -->
<!-- BEGIN: Footer-->
<footer class="page-footer footer footer-static footer-light navbar-border navbar-shadow">
	<div class="footer-copyright">
		<div class="container"><span>&copy; 2020 <a href="../../../../user/pixinvent/portfolio.html?ref=pixinvent" target="_blank">PIXINVENT</a> All rights reserved.</span><span class="right hide-on-small-only">Design and Developed by <a href="https://pixinvent.com/">PIXINVENT</a></span>
		</div>
	</div>
</footer>
<?php include 'ScriptFooter.php';?>